package test.TestMath.TestFormule;

import static org.junit.Assert.assertEquals;

import org.junit.*;

import tableur.exception.NoMeasurableException;

public class TestConstante extends TestSetupFormule{

    @Test
    public void testConstante() throws NoMeasurableException {
        assertEquals(5, const5.evaluer(null), DELTA);
        assertEquals(2, const2.evaluer(null), DELTA);
    }

}
