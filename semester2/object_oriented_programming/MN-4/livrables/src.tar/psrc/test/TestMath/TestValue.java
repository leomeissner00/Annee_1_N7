package test.TestMath;

public class TestValue {
    public final double DELTA = 1e-3;
}
