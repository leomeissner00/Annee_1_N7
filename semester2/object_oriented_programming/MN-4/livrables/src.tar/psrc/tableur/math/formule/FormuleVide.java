package tableur.math.formule;

import java.util.Set;

import tableur.Tableur;
import tableur.composant.Cellule;
import tableur.math.Formule;

public class FormuleVide implements Formule {

    public FormuleVide() {
        super();
    }

    @Override
    public double evaluer(Tableur tab, Set<Cellule> parcouru) {
        return 0;
    }
    
    public String toString() {
        return "";
    }
}
