package tableur.exception;

public class NoFormuleException extends Exception{
        public NoFormuleException() {
            super();
        }
}
