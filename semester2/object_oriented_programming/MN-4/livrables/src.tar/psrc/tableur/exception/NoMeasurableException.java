package tableur.exception;

public class NoMeasurableException extends Exception{
        public NoMeasurableException() {
            super();
        }
        public NoMeasurableException(String text) {
            super(text);
        }

}
