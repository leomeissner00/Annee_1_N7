package tableur.exception;

public class FormatFormuleException extends Exception{
        public FormatFormuleException() {
            super();
        }

        public FormatFormuleException(String string) {
            super(string);
        }
}
