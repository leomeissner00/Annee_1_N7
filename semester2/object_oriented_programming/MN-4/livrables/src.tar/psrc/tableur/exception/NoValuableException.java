package tableur.exception;

public class NoValuableException extends Exception{
        public NoValuableException() {
            super();
        }
}
